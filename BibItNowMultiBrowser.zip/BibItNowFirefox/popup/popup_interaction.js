const BINPopup = ( function () {
	
	//references to parser objects
	const parserList = [BINBibtex,BINRisEnd,BINRisEnd,BINBarnoldS,BINBarnoldS,BINApa,BINMla]
	
	//reference to advanced option page, set to null to indicate that it needs to be rebuilt
	var advancedOptionPage = null;
	
	// function to send messages
	function sendMsg(message, handler) {
		let toFullfill = browser.runtime.sendMessage(message);
		toFullfill.then(handler, 
			function(error) {
				setReadyState(true);
				console.log(`Error: ${error}`);
			}
		);
	}
	
	//css selector that changes text area highlight color, depends on browser
	const cssHighlightColorSelector = "-moz-selection";


	
	// function to open options page
	function openOptionPage(anchor = "") {
		
		//send message to background telling it to open option page, close popup when finished
		sendMsg({ msgType: "popup_open_optionpage_background" , anchor: anchor }, function() { window.close() });
	}

	// handle only parsed bib or error
	function handleMessage(request, sender, sendResponse) {
		
		switch(request.msgType) {
			case "background_bibdata_popup":
				//save data
				bibData = request;
				
				//link to data of individual bibfields
				bibFieldData = bibData.bibFields;
				if (bibFieldData == null || !(Array.isArray(bibFieldData)) || bibFieldData.length < 1) bibFieldData = null;
				
				//set redirection link
				setRedirectionLink({ link: bibData.redirectionLink });
		  
				//rebuild popup
				rebuildPopup(1);
				
				//send acknowledgement response to avoid error messages
				sendResponse( { received: true } );
				break;
			case "background_notextractable_popup":
				//signal in text area that data extraction was not possible
				document.getElementById("textToCopy").value = 'Error: Could not extract source data from page in active tab.';
				
				//set download status to "Site disabled"
				setCitationDownloadIndicator(1);
				
				//enable popup for more data extraction
				setReadyState(true);
				
				//send acknowledgement response to avoid error messages
				sendResponse( { received: true } );
				break;
			case "background_clicking_citation_button_popup":
				//set download status to "In progress..."
				setCitationDownloadIndicator(-1);
				
				//signal in text area that data plugin now attempts to "click citation button for you". State timeout in seconds
				setDownloadTimeoutIndicator(request.timeout);
				
				//send acknowledgement response to avoid error messages
				sendResponse( { received: true } );
				break;
		}
	}
	
	// function to close popup programmatically. href argument kept, since important on Safari
	function closePopup(href) {
		//needs to be asynchronous, since doi link otherwise not functional on some operating systems
		window.setTimeout( function() {
			window.close();
			}, 200
		);
	}
	
	//ask for bibliography data
	function askForBib(message) {
		
		//copy display options
		displayOptions = message.displayOptions;
		generalOptions = message.generalOptions;
		redirectionSchemes = message.redirectionSchemes;
		
		//instruct background system to load bibdata from currently active tab
		sendMsg({ msgType: "popup_retreive_bibdata_background" , clear: false }, doNothing);
		
		//set custom style for text area
		setTextAreaStyle();
		
		//rebuild popup
		rebuildPopup(0);
		
		//populate redirection scheme selector
		buildRedirectionSchemeSelector();
	}

	// function to set download link. Needs to be browser dependent because of lack of proper download property support in Safari
	function setDownloadLink(downloadLink, content, charset, ext) {
		
		//downloadLink.href = "data:text/" + ext + ";charset=" + charset + "," + encodeURIComponent(content);
		downloadLink.href =  URL.createObjectURL(new Blob([content], {type: 'text/'+ext}));
		
		//set file name in download property, prefer custom bibkey if available
		content = bibFieldData[45];
		if (content.length == 0) content = bibFieldData[21];
		downloadLink.download = "" + content + "." + ext;
	}

	// function to set DOI link target, not working on Safari, and hence not included
	function setDOILinkTarget() {
		document.getElementById("doiLink").setAttribute('target','_blank');
	}
	
	// function to retreive options
	function retreiveContent(mess) {
		
		//reset bibData
		bibData = null; bibFieldData = null;
		
		//signal that the popup is currently in the process of retreiving data, disables reload button
		setReadyState(false);
		
		//add event listeners once
		addEventListeners();
		
		//get options and bibfields from background, and then ask for bib data
		sendMsg({ msgType: "request_options_background" }, askForBib);
		
		//set DOILinkTarget
		setDOILinkTarget();
	}
	

	// function to set ready state
	function setReadyState(ready) {
		// set global ready state
		isReady = ready;
		
		// enable/disable reload button and scheme selector
		document.querySelector('.reloadCitation').disabled = !ready;

	}
	
	// function to reload citation
	function reloadCitation() {
		
		//do nothing if popup not ready
		if (!isReady) return;
		  
		//if popup ready, instruct background system to reload bibdata from currently active tab, meaning that the tab will be removed from the cache before retreival!
		bibData = null; bibFieldData = null;
		
		//instruct background system to resend data
		sendMsg({ msgType: "popup_retreive_bibdata_background" , clear: true }, doNothing);
		
		//signal in text area that the data is reloading
		document.getElementById("textToCopy").value = "Loading...";
		
		// prepare for new data retreival
		setReadyState(false);
		setRedirectionLink("");
		setTypeIndicator();
		setCitationDownloadIndicator(-1);
		
	}
	
	// empty handler, do nothing
	function doNothing(message) {
		message = null;//blupp
	}
	
	//function to set text area style
	function setTextAreaStyle() {

		// remove any old style code
		let css = document.getElementById("textareaStyle");
		if (css != null) css.parentNode.removeChild(css);
		
		// if wanted, set new style
		let options = (generalOptions != null && typeof(generalOptions) == 'object') ? generalOptions["set_focus_color"] : false;
		if (options) {
			options = generalOptions["focus_color"];
			if (options != null && options != "") {
				css = document.createElement("style");
				css.type = "text/css";
				css.id = "textareaStyle";
				css.innerText = "#textToCopy::" + cssHighlightColorSelector +" { color: black; background-color: " + options + "; }\n";
				document.body.appendChild(css);
			}
		}
	}
	
	// function to mark text area
	function markTextArea(textArea = null) {
		if (textArea == null) textArea = document.getElementById("textToCopy");
		textArea.setSelectionRange(0,textArea.textLength,"backward");
		textArea.select();
		
		//focus on popup window, must be issued again with timeout to be sure to work
		window.focus();
		window.setTimeout( function(){ textArea.setSelectionRange(0,textArea.textLength,"backward"); textArea.select(); window.focus(); textArea.scrollTop = 0; }, 200);
	}
	
	//function to set redirection link to doi link
	function setDOILink(googleScholar) {
		
		//get reference to link object
		const doiLink = document.getElementById("doiLink");
		
		//disable by default, but enable if doi or url available
		doiLink.removeAttribute('href');
		doiLink.innerText = "Not available.";
		doiLink.title = "Redirection link not available";
		
		if (bibFieldData != null) {
			let href = bibFieldData[15], isbn = bibFieldData[50];
			if (href != "") {
				if (googleScholar == -2) {
					href = "https://scholar.google.com/scholar_lookup?&doi=" + href;
					let title = bibFieldData[1];
					if (title != null && typeof(title) == 'string' && title.length > 0) href += "&title=" + title.replace(/[\s]+/gi,"+");
					doiLink.innerText = "Find article on Google Scholar";
				} else {
					href = "https://doi.org/" + href;
					doiLink.innerText = href;
				}
				doiLink.href = href;
				doiLink.title = href;
			} else if (googleScholar == -2 && isbn != "") {
				href = "https://www.google.com/search?tbo=p&tbm=bks&q=isbn:" + isbn + "&num=10";
				let title = bibFieldData[1];
				doiLink.innerText = "Find book on Google Books";
				doiLink.href = href;
				doiLink.title = href;
			
			} else if (googleScholar != -2 && bibFieldData[30]["citation_url"] != 0) {
				href = bibFieldData[16];
				if (href != "") {
					doiLink.href = href;
					doiLink.innerText = href;
					doiLink.title = href;
				}
			}
		}
	}
	
	//function to set redirection link
	function setRedirectionLink(link) {
		
		//get reference to link object
		const redirectionLink = document.getElementById("doiLink");
		
		//disable by default, but enable if info available
		redirectionLink.removeAttribute('href');
		redirectionLink.innerText = "Not available.";
		redirectionLink.title = "Redirection link not available";
		
		//early out if no redirection schemes available
		if (redirectionSchemes == null || typeof(redirectionSchemes) != 'object') return;
		
		//get current scheme
		let currentScheme = redirectionSchemes.currentScheme;
		
		//fall back to default if wanted
		if (currentScheme < 0) {
			setDOILink(currentScheme);
			return;
		}

		//return if invalid link
		if (link == null || typeof(link) != 'object' || (link = link.link) == null || typeof(link) != 'string' || link.search(/^http[s]?:\/\//) == -1) return;
		
		//set redirection link with info from current scheme
		//link = link.replace(/[\s]+/gi,"+");
		currentScheme = redirectionSchemes.schemes[currentScheme];
		redirectionLink.href = link;
		redirectionLink.innerText = currentScheme.showAsTooltip ? currentScheme.tooltip : link;
		redirectionLink.title = link;
		
	}
	
	//function to set type indicator
	function setTypeIndicator() {
		
		//set default to None/Generic
		const typeIndicator = document.getElementById("contentType");
		typeIndicator.style.color = "black"; typeIndicator.innerText = "Not available";
		
		//reset if type available
		if (bibFieldData != null) {
			switch(bibFieldData[0]) {
				case "article":
					typeIndicator.style.color = "#32A4FF";
					typeIndicator.innerText = "Article";
					return;
				case "phdthesis":
					typeIndicator.style.color = "#32A4FF";
					typeIndicator.innerText = "Thesis";
					return;
				case "book":
					typeIndicator.style.color = "#32A4FF";
					typeIndicator.innerText = "Book";
					return;
				default:
					typeIndicator.style.color = "red";
					typeIndicator.innerText = "None/Generic!";
					return;
				
			}
		}
	}
	
	//function to set dynamic download status
	function setCitationDownloadIndicator(status) {
		const statusIndicator = document.getElementById("dynamicDownloadStatus");
		const reloadButton = document.querySelector('.reloadCitation');
		reloadButton.innerText = "Reload"; //by default, set text to "Reload";
		reloadButton.style["font-weight"] = "normal";
		switch (status) {
			case -1:
				statusIndicator.innerText = "In progress...";
				statusIndicator.style.color = "black";
				break;
			case 0:
				let isEnabled = generalOptions["dyn_download"];
				if (isEnabled == null) isEnabled = true;
				if (!isEnabled) {
					statusIndicator.innerText = "Globally disabled!";
					statusIndicator.style.color = "black";
				} else {
					statusIndicator.innerText = "Please reload!";
					statusIndicator.style.color = "red";
					
					//set reload button text to "RELOAD", to signal the user that he/she should ACTUALLY use it!
					reloadButton.innerText = "RELOAD";
					reloadButton.style["font-weight"] = "bold";
				}
				break;
			case 1:
				statusIndicator.innerText = "Not available.";
				statusIndicator.style.color = "black";
				break;
			case 2:
				statusIndicator.innerText = "Failed!";
				statusIndicator.style.color = "red";
				//set reload button text to "RETRY", to signal the user that he/she should ACTUALLY use it!
				reloadButton.innerText = "RETRY";
				reloadButton.style["font-weight"] = "bold";
				break;
			case 3:
				statusIndicator.innerText = "Successful!";
				statusIndicator.style.color = "#32A4FF";
				break;
			case 4:
				statusIndicator.innerText = "Incompatible format!";
				statusIndicator.style.color = "red";
				
				//set reload button text to "RETRY", to signal the user that he/she should ACTUALLY use it!
				reloadButton.innerText = "RETRY";
				reloadButton.style["font-weight"] = "bold";
				break;
			default:
				statusIndicator.innerText = "Awating status...";
				statusIndicator.style.color = "black";
		}
	}
	
	//function that indicates citation download and timeout in text area
	function setDownloadTimeoutIndicator(timeout) {
		
		//format timeout to seconds
		if (timeout != null && timeout === parseInt(timeout, 10)) {
			timeout /= 1000;
			if (timeout == 0) timeout = "1";
		} else {
			//default
			timeout = "a few";
		}
		
		//update text area
		document.getElementById("textToCopy").value = "Trying to download better citation data. This may take up to " + timeout + " seconds...";
	}
	
	//function to set display options in background
	function setDisplayOption(parseMode, option, value) {
		
		//locally reset display option
		displayOptions.optionArray[parseMode][option] = value;
		
		//update in background
		const options = {};
		options[option] = value;
		sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: options }, doNothing);
		
		//rebuild popup
		rebuildPopup(1);
	}
	
	//function to populate redirection scheme selector
	function buildRedirectionSchemeSelector() {
		//early out
		if (redirectionSchemes == null || typeof(redirectionSchemes) != 'object') return;
		
		//schemes
		const schemes = redirectionSchemes.schemes, currentScheme = redirectionSchemes.currentScheme;
		const length = schemes.length;
		
		//repopulate selector
		const schemeSelector = document.getElementById('redirectionSelectorBox');
		
		//remove all elements
		while (schemeSelector.hasChildNodes()) {
			schemeSelector.removeChild(schemeSelector.childNodes[0]);
		}
		
		//add default element with value -2
		let option = document.createElement("option");
		option.value = -2; option.innerText = "Google";
		schemeSelector.appendChild(option);
		
		//add default element with value -1
		option = document.createElement("option");
		option.value = -1; option.innerText = "DOI/URL";
		schemeSelector.appendChild(option);
		
		//add all custom elements
		for (let i = 0; i<length; ++i) {
			option = document.createElement("option");
			option.value = i; option.innerText = schemes[i].name;
			schemeSelector.appendChild(option);
		}
		
		//select current scheme
		schemeSelector.value = currentScheme;
	}
	
	//renew popup content
	function rebuildPopup(mode) {
				
		//get display options and parse mode, do not rebuild if options are not available
		if (displayOptions == null || typeof(displayOptions) != 'object') return;
		const parseMode = displayOptions.parseMode;
		if (!(parseMode >= 0)) return;
		let options = displayOptions.optionArray;
		if (options == null) return;
		options = options[parseMode];
		if (options == null || typeof(options) != 'object') return;
		
		//get parser and parse info, containing name, file extension, encoding etc.
		const parser = parserList[parseMode];
		const parserInfo = parser.getParserInfo(parseMode);
		
		//parse mode specific abbreviation setting, needed later
		let abbrevs = options["abbrevs"]; 
		  
		//mode = 0 is for resetting control panel, 1 for text field and download button, 2 or higher for both
		if (mode == 0 || mode > 1) {
			
			//if necessary, asynchronously remove all elements from advanced option page and rebuild
			if (advancedOptionPage == null) {
				
				//get advanced option page
				const advOptPage = document.getElementById('advancedOptions');
				
				//hide advanced option page by default and set default height
				advOptPage.style.display = "none";
				
				//remove previous elements
				while (advOptPage.hasChildNodes()) {
					advOptPage.removeChild(advOptPage.lastChild);
				}
				
				//and add new elements specific to citation format
				
				//add title
				let elem = document.createElement("h1");
				elem.innerText = "Advanced settings for " + parserInfo.name + " format";
				advOptPage.appendChild(elem); 
				advOptPage.appendChild(document.createElement("br"));
				
				//add options, parser specific
				if(!parser.buildAdvancedOptionPage(parseMode,advOptPage,setDisplayOption)) {
					//if parser does not add option, excuse :)
					elem = document.createElement("center");
					elem.innerText = "Sorry, no advanced settings available for this citation format."
					advOptPage.appendChild(elem);
				}

				//indicate that rebuilding advanced option page is not necessary
				advancedOptionPage = advOptPage;
			}
			
			//abbreviation box
			const abbrevBox = document.getElementById('journalAbbrevBox');
			const abbrevBoxText = document.getElementById('checkBoxText');
			const abbrevDotSelector = document.getElementById('dotSelectorBox');
			abbrevBox.checked = abbrevs;
			abbrevBox.disabled = false;
			abbrevBoxText.style.color = "black";
			abbrevDotSelector.value = options["abbrevDots"] ? "1" : "0";
			abbrevDotSelector.disabled = abbrevs ? false : true;
			
			//author box
			const authorBox = document.getElementById('maxNumAuthorsBox');
			const authorBoxText = document.getElementById('maxNumAuthorsText');
			authorBox.checked = options["forceMaxNumAuthors"];
			authorBox.disabled = true;
			authorBoxText.style.color = "grey";
			
			//author field
			const authorField = document.getElementById('maxNumAuthorsField');
			authorField.disabled = true;
			authorField.value = options["maxNumAuthors"];
			
			//parse mode selector
			document.getElementById('filterSelectorBox').value = "" + parseMode;
			
			//parse mode dependent adjustments
			if (parseMode == 0 || (parseMode > 2 && parseMode < 5) ){
				authorBox.disabled = false;
				authorBoxText.style.color = "black";
				authorField.disabled = !authorBox.checked;
			} else if (parseMode == 1) {
				abbrevBox.disabled = true;
				abbrevBoxText.style.color = "grey";
				abbrevDotSelector.disabled = false;
			}
		}
		
		if (mode > 0 && bibData != null && typeof(bibData) == 'object' && bibFieldData != null) {
			
			//set citation download indicator
			setCitationDownloadIndicator(bibData["citation_download_status"]);
			
			//parse bib data
			const contentString = parser.parse(parseMode,abbrevs);
			
			//create download link, make this browser dependent for stupid support of download property in Safari, grrrrrrr Apple!!!
			setDownloadLink(document.getElementById("downloadLink"), contentString, parserInfo.encoding, parserInfo.fileExtension);
			
			//set type indicator
			setTypeIndicator();
			
			//fill textArea depending on mode, and scroll to top
			const textArea = document.getElementById("textToCopy");
			textArea.value = contentString;
			textArea.scrollTop = 0;
			
			
			//select text area if option enabled
			if (generalOptions["text_autofocus"]) {
				markTextArea(textArea);
			}
			
			//signal that the popup is ready to take new data
			setReadyState(true);			
		}
		
	}
	
	// function to add event listeners to UI elements
	function addEventListeners() {
		
		//reload button functionality
		document.querySelector('.reloadCitation').addEventListener('click', function(event) {
				reloadCitation();
			}
		);
		
		//copy to clipboard button functionality
		document.querySelector('.copyToClipboard').addEventListener('click', function(event) {
				document.getElementById("textToCopy").select();
				try {
					document.execCommand('copy');
				} catch (err) {
					console.log('Unable to copy');
				}
			}
		);
		
		//reparse content if abbreviation available!
		document.getElementById('journalAbbrevBox').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get parse mode and value
				const parseMode = displayOptions["parseMode"];
				const value = this.checked;
				
				//update display options in background
				sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: { abbrevs: value } }, doNothing);
				
				//set abbreviation option and rebuild popup if necessary
				displayOptions["optionArray"][parseMode]["abbrevs"] = value;
				if (bibFieldData != null && bibFieldData[7] != "" && bibFieldData[8] != "") {
					rebuildPopup(2);
				} else {
					rebuildPopup(0);
					if (generalOptions["text_autofocus"] && bibFieldData != null) markTextArea();
				}
				
				//mark as ready
				setReadyState(true);
			}
		);
		
		//reparse content if abbreviation available and dots enabled/disabled!
		document.getElementById('dotSelectorBox').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get parse mode and value
				const parseMode = displayOptions["parseMode"];
				const value = (this.value == "1");
				
				//update display options in background
				sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: { abbrevDots: value } }, doNothing);
				
				//set abbreviation option and rebuild popup if necessary
				displayOptions["optionArray"][parseMode]["abbrevDots"] = value;
				if (bibFieldData != null && bibFieldData[7] != "" && bibFieldData[8] != "") {
					rebuildPopup(1);
				} else if (generalOptions["text_autofocus"] && bibFieldData != null) {
					markTextArea();
				}
									   
				//enable reload
				setReadyState(true);
				
			}
		);
		
		//reparse content if forceMaxNumAuthors checkBox changed
		document.getElementById('maxNumAuthorsBox').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get parse mode and value
				const parseMode = displayOptions["parseMode"];
				const value = this.checked;
				
				//update display options in background
				sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: { forceMaxNumAuthors: value } }, doNothing);
				
				//set abbreviation option and rebuild popup if necessary
				displayOptions["optionArray"][parseMode]["forceMaxNumAuthors"] = value;
				
				//rebuild popup with a mode that depends on whether author information is available or not
				if (bibFieldData != null && (parseMode == 0 || parseMode > 2) && bibFieldData[3] != "" && bibFieldData[4] != "") {
					rebuildPopup(2);
				} else {
					rebuildPopup(0);
					if (generalOptions["text_autofocus"] && bibFieldData != null) markTextArea();
				}
				
				//mark as ready
				setReadyState(true);
			}
		);
		
		//reparse if maxNumAuthorsField changed
		document.getElementById('maxNumAuthorsField').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get parse mode and value
				const parseMode = displayOptions["parseMode"];
				const value = this.value;
				
				//update display options in background
				sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: { maxNumAuthors: value } }, doNothing);
				
				//set abbreviation option and rebuild popup if necessary
				displayOptions["optionArray"][parseMode]["maxNumAuthors"] = value;
				
				//rebuild popup with a mode that depends on whether author information is available or not
				if (bibFieldData != null && (parseMode == 0 || parseMode > 2) && bibFieldData[3] != "" && bibFieldData[4] != "") {
					rebuildPopup(2);
				} else {
					rebuildPopup(0);
					if (generalOptions["text_autofocus"] && bibFieldData != null) markTextArea();
					
				}
				
				//mark as ready
				setReadyState(true);
			}
		);
		
		
		//reparse content if parser changed
		document.getElementById('filterSelectorBox').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get new parse mode
				const parseMode = parseInt(this.options[this.selectedIndex].value);
				
				//update parse options in background
				sendMsg({ msgType: "update_display_options_background" , parseMode: parseMode , options: { setParseMode: true } }, doNothing);
				
				//set parseMode option depending on selected item in drop down menu
				displayOptions["parseMode"] = parseMode;
				
				//reset advanced option page
				advancedOptionPage = null;
				
				//rebuild popup
				rebuildPopup(2);
				
				//mark as ready
				setReadyState(true);
				
			}
		);
		
		//open global option page
		document.getElementById('optionLink').addEventListener('click',function(event) {
				openOptionPage();
			}
		);
		
		//open advanced options page
		document.getElementById('advancedOptionsLink').addEventListener('click',function(event) {
				const advOptPage = document.getElementById('advancedOptions');
				advOptPage.style.display = "inline";
				advOptPage.focus();
			}
		);
		
		//open redirection scheme page
		document.getElementById('editSchemeLink').addEventListener('click',function(event) {
				openOptionPage("redirectionSchemeUI");
			}
		);
		
		//select redirection scheme
		document.getElementById('redirectionSelectorBox').addEventListener('change',function(event) {
				
				//disable reload
				setReadyState(false);
			
				//get selected scheme and set it locally
				const scheme = parseInt(this.options[this.selectedIndex].value);
				redirectionSchemes.currentScheme = scheme;
				
				//update scheme in background, send tab id if data available to update link
				sendMsg({ msgType: "set_redirection_scheme_background" , currentScheme: scheme , tab: bibData != null ? bibData["tab_id"] : null }, setRedirectionLink );
				
				//remark text area
				if (generalOptions["text_autofocus"] && bibFieldData != null) markTextArea();
				
				//mark as ready
				setReadyState(true);
				
			}
		);
		
		//close advanced options page if focus is lost or if clicked somewhere else. Remark text area if wanted		
		document.body.addEventListener('focusin',function(event) {
				const advOptPage = document.getElementById('advancedOptions');
				let activeElem;
				if (advOptPage.style.display != "none" && !advOptPage.contains((activeElem = document.activeElement)) && (activeElem = activeElem.id) != "advancedOptions" && activeElem != "textToCopy" && activeElem != "filterSelectorBox" && activeElem != "maxNumAuthorsField" && activeElem != "dotSelectorBox" ) {
					advOptPage.style.display = "none";
					if(generalOptions["text_autofocus"] && bibFieldData != null) markTextArea();
				}
			}
		);
		{
			const elems = ['filterSelector','exportButtons','dynamicDownloadIndicator','options','optionLinkDiv','doi','textToCopy','textAreaDiv'];
			for (let i = 0; i<8; ++i) {
				document.getElementById(elems[i]).addEventListener('click', function(event) { 
						const advOptPage = document.getElementById('advancedOptions');
						if (advOptPage.style.display != "none") {
							advOptPage.style.display = "none";
							let activeId = document.activeElement.id;
							if(generalOptions["text_autofocus"] && activeId != "filterSelectorBox" && activeId != "maxNumAuthorsField" && activeId != "dotSelectorBox" && bibFieldData != null) {
								markTextArea();
							}
						}
					}
						
				);
			}
		}
		
		//close popup when pressing doi link
		document.getElementById('doiLink').addEventListener('click',function(event) {
				closePopup(this.href);
			}
		);
				
	}
	// return retreiveContent, handleMessage
	return {
		retreiveContent : retreiveContent,
		handleMessage : handleMessage
	}; //end return
}());