const BINBarnoldS = ( function () {
	
	//function to build advanced option page
	function buildAdvancedOptionPage(parseMode, advancedOptionPage, setDisplayOption) {
		
		// function to refresh advanced option page
		function refreshAdvancedOptionPage(index, parseMode) {
			if (index == 4) {
				let doIt = displayOptions.optionArray[parseMode]["showYear"];
				document.getElementById('showYearInCenturyText').style.color = doIt ? "black" : "grey";
				document.getElementById('showYearInCentury').disabled = !doIt;
			} else if (index == 6) {
				let doIt = displayOptions.optionArray[parseMode]["showFirstNames"];
				document.getElementById('forceInitialsText').style.color = doIt ? "black" : "grey";
				document.getElementById('forceInitials').disabled = !doIt;
				document.getElementById('invertNameOrderText').style.color = doIt ? "black" : "grey";
				document.getElementById('invertNameOrder').disabled = !doIt;
			} else if (index == 9) {
				let doIt = displayOptions.optionArray[parseMode]["etAlMode"];
				document.getElementById('etAlNumAuthors').disabled = !doIt;
				document.getElementById('etAlAuthor').disabled = !doIt;
			}
		}
		
		//set height
		advancedOptionPage.style["height"] = "9.2cm";
		
		//center element
		const centerElem = document.createElement("center");
		centerElem.style.margin = "0 auto"; centerElem.style.width = "100%"; centerElem.style.padding = "0cm";
		advancedOptionPage.appendChild(centerElem);
		
		//add info text
		{
			const infoText = document.createElement("p");
			infoText.style["text-align"] = "center";
			infoText.innerText = (parseMode == 3 ? "Arnold S." : "Barnold S.") + " offers \"sloppy\" citations and allows YOU to set rules.";
			centerElem.appendChild(infoText); centerElem.appendChild(document.createElement("br"));
		}
		
		//add table in center element
		let table = document.createElement("table");
		table.style = "margin: 0 auto;";
 		centerElem.appendChild(table);
		
		//create elements, add event listener and add to advanced option page
		const options = ["showJournalTitle","showTitle","showVolume","showIssue","showYear","showYearInCentury","showFirstNames","invertNameOrder","forceInitials","etAlMode"];
		const titles = ["Show journal/book/thesis/website title","Show article/chapter Title","Show journal volume","Show journal issue or pages","Show year/date","Force year within century","Show first/middle names","Show first/middle names after surnames","Force initials for first/middle names","Force \"et al.\" after author "];
		
		//add option for dotless i,j for Barnold
		if (parseMode != 3) {
			options[options.length] = options[options.length-1];
			options[options.length-2] = "dotlessMode";
			titles[titles.length] = titles[titles.length-1];
			titles[titles.length-2] = "Replace \"{\\i}\",\"{\\j}\" by \"{i}\",\"{j}\"";
		}
		const length = options.length;
		let tableRow, tableCell;
		for (let i = 0; i<length; ++i) {
			
			tableRow = document.createElement("tr");
			table.appendChild(tableRow);
			
			
			
			//create and append checkbox
			tableCell = document.createElement("td");
			tableRow.appendChild(tableCell);
			let elem = document.createElement("input");
			elem.type = "checkbox"; elem.title = titles[i]; elem.id = options[i];
			elem.checked = displayOptions.optionArray[parseMode][options[i]];
			tableCell.appendChild(elem);
			
			//make it functional
			elem.addEventListener('change', function(event) {
					setDisplayOption(parseMode, options[i],this.checked == true);
					refreshAdvancedOptionPage(i, parseMode);
				}
			);
			
			//add checkbox text
			tableCell = document.createElement("td");
			tableRow.appendChild(tableCell);
			elem = document.createElement("span"); elem.title = titles[i]; elem.id = options[i] + "Text"; elem.innerText = titles[i];
			tableCell.appendChild(elem);
		}
		
		//add number box for etAlMode last author to show
		let elem = document.createElement("input");
		elem.type = "number"; elem.min = "1"; elem.title = "Author (in sequence) after which \"et al.\" is forced"; elem.id = "etAlAuthor"; elem.value = displayOptions.optionArray[parseMode].etAlAuthor; elem.disabled = !(displayOptions.optionArray[parseMode].etAlMode);
		tableCell.appendChild(elem);
		
		//activate number field
		elem.addEventListener('change',function(event) {
				if (this.value < this.min || this.value != this.value) this.value = this.min;
				setDisplayOption(parseMode, "etAlAuthor", this.value);
			}
		);
		
		//add text after number field
		elem = document.createElement("span"); elem.title = "etAlAuthorText"; elem.id = "etAlAuthorText"; elem.innerText = " if more than ";
		tableCell.appendChild(elem);
		
		//add number box for etAlMode authors
		elem = document.createElement("input");
		elem.type = "number"; elem.min = "1"; elem.title = "Highest number of authors for which \"et al.\" is not forced"; elem.id = "etAlNumAuthors"; elem.value = displayOptions.optionArray[parseMode].etAlNumAuthors; elem.disabled = !(displayOptions.optionArray[parseMode].etAlMode);
		tableCell.appendChild(elem);
		
		//activate number field
		elem.addEventListener('change',function(event) {
				if (this.value < this.min || this.value != this.value) this.value = this.min;
				document.getElementById("etAlNumAuthorsText").innerText = this.value > 1 ? " authors" : " author";
				setDisplayOption(parseMode, "etAlNumAuthors", this.value);
			}
		);
		
		//add text after number field
		elem = document.createElement("span"); elem.title = "etAlNumAuthorsText"; elem.id = "etAlNumAuthorsText"; elem.innerText = displayOptions.optionArray[parseMode].etAlNumAuthors > 1 ? " authors" : " author";
		tableCell.appendChild(elem);
		
		//refresh page
		refreshAdvancedOptionPage(4, parseMode); refreshAdvancedOptionPage(6, parseMode); refreshAdvancedOptionPage(9, parseMode);
		
		return true;
	}
	
	//parse to Arnold-S format
	function parseToArnoldS(mode,abbrevs) {
		
		// empty return string
		let returnString = "";
		
		// book keeping (haha)
		let isBook = false;
		
		// mode and abbreviation dependent field values
		const fieldNumbers = [/*journal title_abbrev*/7,/*journal title*/5,/*title_book*/1,/*author_list*/3,/*initials*/28,/*article title*/1,/*journal title_abbrev_nodot*/47];
		if (mode == 4) {
			fieldNumbers[0] = 8; fieldNumbers[1] = 6; fieldNumbers[2] = 2; fieldNumbers[3] = 4;  fieldNumbers[4] = 29; fieldNumbers[5] = 2; fieldNumbers[6] = 48;
		}
		
		// get display options and citation type
		const options = displayOptions.optionArray[mode];
		const arnoldShould = displayOptions.optionArray[mode];
		const citType = bibFieldData[0];
		
		// check if (abbreviated) journal name or book title available
		let mainTitle;
		if (citType == "book") {
			mainTitle = bibFieldData[fieldNumbers[2]];
			isBook = true;
		} else if(citType == "phdthesis") {
			mainTitle = bibFieldData[fieldNumbers[2]];
		} else {
			if (abbrevs) {
				//take care of dots in abbreviations
				mainTitle = options.abbrevDots ? bibFieldData[fieldNumbers[0]] : bibFieldData[fieldNumbers[6]];
				if (mainTitle == "") mainTitle = bibFieldData[fieldNumbers[1]];			
			} else {
				mainTitle = bibFieldData[fieldNumbers[1]];
			}		
		}
		
		//if journal or book title not available, only spit out webpage title and date
		if (mainTitle != "") {
			
			//insert possibly truncated author list
			let separator = " ";
			let fieldValue = bibFieldData[fieldNumbers[3]];
			let length = fieldValue.length;
			if (length > 0) {
				let numLines = length;
				if (options["forceMaxNumAuthors"]) {
					numLines = options["maxNumAuthors"];
					numLines = (length <= numLines) ? length : numLines;
				}
				
				//implement et al mode here
				if (options["etAlMode"]) {
					let etAlAuthor = options["etAlAuthor"];
					if (etAlAuthor > numLines) etAlAuthor = numLines;
					numLines = (length > options["etAlNumAuthors"]) ? etAlAuthor : numLines;
				}
				
				if (numLines > 0) {
					//temporarily save initials
					const initials = bibFieldData[fieldNumbers[4]];
					
					//get options for showing author names
					const firstNames = arnoldShould.showFirstNames, forceInitials = arnoldShould.forceInitials, invertNameOrder = arnoldShould.invertNameOrder;
					
					//take into account whether or not order first/surname should be reversed
					const nameComponents = ["",""], nameIdx = [0,1];
					let authorSep = ", ";
					if (invertNameOrder) {
						nameIdx[0] = 1; nameIdx[1] = 0;
						if (firstNames) authorSep = " and ";
					}
					
					//loop over authors
					for (let i = 0; i<numLines; ++i) {
						
						//get name components
						let name = fieldValue[i];
						
						//set first name
						let partSep = invertNameOrder ? ", " : " ";
						if (firstNames && name[2].length > 0) {
							nameComponents[nameIdx[0]] = (forceInitials && initials[i].length > 0) ? initials[i] : name[2];
						} else {
							nameComponents[nameIdx[0]] = "";
							partSep = "";
						}
						
						//set surname + jr,sr if available
						nameComponents[nameIdx[1]] = name[0]
						if (name[1].length > 0) nameComponents[nameIdx[1]] += " " + name[1];
						
						//add author to return string
						name = nameComponents[0] + partSep + nameComponents[1];
						if (mode == 4) name = name.replace(/(^[\s]*\{[\s]*|[\s]*\}[\s]*$)/g,"");
						returnString += name + authorSep;

					}
					
					//add "et al." to end if necessary, and finish with colon
					returnString = returnString.replace(/[\ ]*(?:,|and)\ $/,(numLines < length ? " et al." : ""));
					separator = ": ";
				}
			}
			
			//add article/chapter title
			if (arnoldShould.showTitle && citType != "phdthesis") {
				let title = bibFieldData[fieldNumbers[5]];
				if (title != "") {
					returnString += separator + title;
					if (title.search(/[\.!\?]$/) == -1) returnString += ".";
					separator = " ";
				}
			}
			
			//now add journal title or book title
			if (arnoldShould.showJournalTitle) {
				returnString += separator + mainTitle;
				separator = " ";
			}
			
			// for journal add volume and firstpage/issue if available
			if (!isBook) {
				if ((fieldValue = bibFieldData[9]) != "" && arnoldShould.showVolume) {
					
					//mode dependent emphasis of volume
					mainTitle = length = "";
					if (mode == 4) {
						mainTitle = '\\textbf{'; length = '}';
					}
					returnString += separator + mainTitle + fieldValue + length;
					if (arnoldShould.showIssue) {
						if ((fieldValue = bibFieldData[11]) != "" && (fieldValue.search(/[a-z]/i) == -1 || bibFieldData[10] == "")) {
							returnString += ", " + fieldValue.replace(/--.*$/,"");
						} else if ((fieldValue = bibFieldData[10]) != "") {
							returnString += ", " + fieldValue;
						}
					}
				} else if ((fieldValue = bibFieldData[20]) != "" && arnoldShould.showVolume) {
					returnString += separator + fieldValue;
				} else if (arnoldShould.showIssue) {
					if ((fieldValue = bibFieldData[11]) != "" && (fieldValue.search(/[a-z]/i) == -1 || bibFieldData[10] == "")) {
						returnString += separator + fieldValue.replace(/--.*$/,"");
					} else if ((fieldValue = bibFieldData[10]) != "") {
						returnString += separator + fieldValue;
					}
				}
			}
			
			//if arxiv in short form, adjust
			returnString = returnString.replace(/arXiv\ /,"arXiv:").trim();
			
			//add year
			if ((fieldValue = bibFieldData[13]) != "" && arnoldShould.showYear) {
				if (arnoldShould.showYearInCentury) fieldValue = fieldValue.slice(-2);
				returnString += (returnString != "") ? " (" + fieldValue + ")" : fieldValue;
			}
			
		} else {
			if (arnoldShould.showJournalTitle) returnString += bibFieldData[fieldNumbers[2]];
			if (arnoldShould.showYear) {
				let date = bibFieldData[22].replace(/\//g,"-").replace(/[\-]*$/,"");
				if (arnoldShould.showYearInCentury) date = date.slice(2);
				returnString += (returnString != "") ? " (" + date + ")" : date;
			}
		}
		
		//dotless mode
		if (arnoldShould.dotlessMode) returnString = returnString.replace(/\\([`'^"~=u])\{\\([ij])\}/g,
			function(match, $1, $2, offset, original) {
				return "\\"+$1+"{"+$2+"}";
			}
		);
		
		if (returnString == "") returnString = "Come on, Cohagen! You got what you want! Give seeze people aiaa!"
		
		//return
		return returnString.trim();
	}
	
	// function that returns parse mode info
	function getParserInfo(parseMode) {
		const retObj = { fileExtension: "txt" };
		if (parseMode == 3) {
			retObj.name = "Arnold S.";
			retObj.encoding = "utf-8";
		} else {
			retObj.name = "Barnold S.";
			retObj.encoding = "us-ascii";
		}
		return retObj;
	}
	
	// return
	return {
		parse : parseToArnoldS,
		buildAdvancedOptionPage : buildAdvancedOptionPage,
		getParserInfo: getParserInfo
	}; //end return
}());